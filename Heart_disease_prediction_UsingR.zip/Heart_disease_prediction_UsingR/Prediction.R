# Clear environment
rm(list = ls())

# Install and load the required packages
install.packages(c("class", "e1071", "caret", "ggcorrplot", "dplyr", "ggplot2", "randomForest", "xgboost"))
library(class)
library(e1071)
library(caret)
library(ggcorrplot)
library(dplyr)
library(ggplot2)
library(randomForest)
library(xgboost)

# Read the data
heart <- read.csv("C:\\Users\\ASUS\\OneDrive - Vishwakarma Institute of Technology\\DS\\Heart_disease_prediction_UsingR\\heart.csv")

# Display first 10 rows of the dataset
print(head(heart, 10))

# Set seed for reproducibility
set.seed(123)

# Sample the dataset
heart <- heart[sample(nrow(heart)), ]

# Define a normalization function
normalize <- function(x) {
  return((x - min(x)) / (max(x) - min(x)))
}

# Normalize the predictors (columns 1 to 13)
normalized_df <- as.data.frame(lapply(heart[, c(1:13)], normalize))
print(normalized_df)

# Calculate the correlation matrix
correlation_matrix <- cor(heart)

# Visualize the correlation matrix using ggcorrplot
ggcorrplot(correlation_matrix, 
           hc.order = TRUE, # Hierarchical clustering order
           type = "lower", # Display lower triangle
           lab = TRUE, # Display labels
           lab_size = 3, # Label size
           method = "circle", # Method for correlation coefficient visualization
           colors = c("yellow", "white", "red"), # Color scale
           title = "Correlation Plot of Heart Dataset", # Title
           ggtheme = theme_bw() # Theme
)

# Scatter plot of Age vs Cholesterol with custom colors based on target
ggplot(heart, aes(x = age, y = chol, color = factor(target))) +
  geom_point() +
  labs(x = "Age", y = "Cholesterol", title = "Scatter Plot of Cholesterol Vs Age") +
  scale_color_manual(values = c("blue", "red"))  # Set custom colors

# Split data into training and testing sets using caret
set.seed(123)
index <- createDataPartition(heart$target, p = 0.8, list = FALSE)

# Training data
train_data <- heart[index, ]

# Testing data
test_data <- heart[-index, ]

# Logistic Regression
logistic_model <- glm(target ~ cp + thalach + slope + exang + oldpeak + thal + ca, 
                      data = train_data,
                      family = "binomial"
)

# Make predictions
predictions <- predict(logistic_model, newdata = test_data, type = "response")
predicted_labels <- ifelse(predictions > 0.5, 1, 0)

# Confusion matrix
conf_matrix <- table(Actual = test_data$target, Predicted = predicted_labels)
print(conf_matrix)

# Accuracy
accuracy <- sum(diag(conf_matrix)) / sum(conf_matrix)
cat("\nThe accuracy of Logistic Regression is: ", round(accuracy * 100, 2), "%\n")

# Random Forest
rf_model <- randomForest(target ~ cp + thalach + slope + exang + oldpeak + thal + ca,
                         data = train_data,
                         ntree = 500,
                         mtry = 3,
                         importance = TRUE
)

rf_prediction <- predict(rf_model, newdata = test_data)
rf_prediction_binary <- ifelse(rf_prediction > 0.5, 1, 0)

# Confusion matrix
rf_conf_matrix <- table(Actual = test_data$target, Predicted = rf_prediction_binary)
print(rf_conf_matrix)

# Accuracy
rf_accuracy <- sum(diag(rf_conf_matrix)) / sum(rf_conf_matrix)
cat("\nRandom Forest Accuracy: ", round(rf_accuracy * 100, 2), "%\n")

# SVM
svm_model <- svm(target ~ cp + thalach + slope + exang + oldpeak + thal + ca,
                 data = train_data,
                 kernel = "linear",
                 cost = 1
)

svm_prediction <- predict(svm_model, newdata = test_data)

svm_prediction_binary <- ifelse(svm_prediction > 0.5, 1, 0)

# Confusion matrix
svm_conf_matrix <- table(Actual = test_data$target, Predicted = svm_prediction_binary)
print(svm_conf_matrix)

# Accuracy
svm_accuracy <- sum(diag(svm_conf_matrix)) / sum(svm_conf_matrix)
cat("\nSVM Accuracy: ", round(svm_accuracy * 100, 2), "%\n")

# XGBoost
xgb_model <- xgboost(data = as.matrix(train_data[, c("cp", "thalach", "slope", "exang", "oldpeak", "thal", "ca")]), 
                     label = train_data$target,
                     objective = "binary:logistic",
                     nrounds = 10,
                     eta = 0.3,
                     max_depth = 6
)

xgb_prediction <- predict(xgb_model, as.matrix(test_data[, c("cp", "thalach", "slope", "exang", "oldpeak", "thal", "ca")]), type = "response")
xgb_prediction_binary <- ifelse(xgb_prediction > 0.5, 1, 0)

# Confusion matrix
xgb_conf_matrix <- table(Actual = test_data$target, Predicted = xgb_prediction_binary)
print(xgb_conf_matrix)

# Accuracy
xgb_accuracy <- sum(diag(xgb_conf_matrix)) / sum(xgb_conf_matrix)
cat("\nXGBoost Accuracy: ", round(xgb_accuracy * 100, 2), "%\n")

# Calculate MSE
mse <- mean((test_data$target - predicted_labels)^2)

# Calculate RMSE
rmse <- sqrt(mse)

# Calculate R-squared
var_y <- var(test_data$target)
r_squared <- 1 - (mse / var_y)

# Display MSE, RMSE, and R-squared
cat("Mean Squared Error (MSE): ", round(mse, 2), "\n")
cat("Root Mean Squared Error (RMSE): ", round(rmse, 2), "\n")
cat("R-squared (R^2): ", round(r_squared, 2), "\n")

# Function to Predict Heart Disease
predict_heart_disease <- function(age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal) {
  # Load necessary packages
  library(class)
  library(e1071)
  library(caret)
  library(randomForest)
  library(xgboost)
  
  # Read the dataset
  heart <- read.csv("C:\\Users\\ASUS\\OneDrive - Vishwakarma Institute of Technology\\DS\\Cp1\\heart.csv")
  
  # Normalize the predictors
  normalize <- function(x) {
    return((x - min(x)) / (max(x) - min(x)))
  }
  heart[, c(1:13)] <- as.data.frame(lapply(heart[, c(1:13)], normalize))
  
  # Combine the user inputs into a data frame
  user_data <- data.frame(age = age, sex = sex, cp = cp, trestbps = trestbps, chol = chol, fbs = fbs,
                          restecg = restecg, thalach = thalach, exang = exang, oldpeak = oldpeak,
                          slope = slope, ca = ca, thal = thal)
  
  # Normalize user data based on the training data
  for (col in colnames(user_data)) {
    user_data[, col] <- (user_data[, col] - min(heart[, col])) / (max(heart[, col]) - min(heart[, col]))
  }
  
  # Train-test split
  set.seed(123)
  index <- createDataPartition(heart$target, p = 0.8, list = FALSE)
  train_data <- heart[index, ]
  test_data <- heart[-index, ]
  
  # Logistic Regression
  logistic_model <- glm(target ~ cp + thalach + slope + exang + oldpeak + thal + ca, 
                        data = train_data,
                        family = "binomial")
  lr_prediction <- ifelse(predict(logistic_model, newdata = user_data, type = "response") > 0.5, "yes", "no")
  
  # Random Forest
  rf_model <- randomForest(target ~ cp + thalach + slope + exang + oldpeak + thal + ca, 
                           data = train_data,
                           ntree = 500)
  rf_prediction <- ifelse(predict(rf_model, newdata = user_data) > 0.5, "yes", "no")
  
  # Support Vector Machine (SVM)
  svm_model <- svm(target ~ cp + thalach + slope + exang + oldpeak + thal + ca,
                   data = train_data,
                   kernel = "linear")
  svm_prediction <- ifelse(predict(svm_model, newdata = user_data) > 0.5, "yes", "no")
  
  # XGBoost
  xgb_model <- xgboost(data = as.matrix(train_data[, c("cp", "thalach", "slope", "exang", "oldpeak", "thal", "ca")]), 
                       label = train_data$target,
                       objective = "binary:logistic",
                       nrounds = 10,
                       eta = 0.3,
                       max_depth = 6)
  xgb_prediction <- ifelse(predict(xgb_model, as.matrix(user_data[, c("cp", "thalach", "slope", "exang", "oldpeak", "thal", "ca")]), type = "response") > 0.5, "yes", "no")
  
  # Return the predicted classes from all models
  return(list(Logistic_Regression = lr_prediction,
              Random_Forest = rf_prediction,
              SVM = svm_prediction,
              XGBoost = xgb_prediction))
}

# Example usage of predict_heart_disease function
# Replace the values below with actual inputs to predict
predicted_results <- predict_heart_disease(age = 60, sex = 1, cp = 2, trestbps = 140, chol = 240, fbs = 0, restecg = 1, thalach = 145, exang = 1, oldpeak = 2.5, slope = 2, ca = 0, thal = 2)
print(predicted_results)


