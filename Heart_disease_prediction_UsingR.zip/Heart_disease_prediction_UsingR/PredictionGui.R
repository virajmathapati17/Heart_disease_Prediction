# Install and load necessary packages
if (!requireNamespace("shiny", quietly = TRUE)) {
  install.packages("shiny")
}
library(shiny)

# Define the function
predict_heart_disease <- function(age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal) {
  # Load necessary packages
  library(class)
  library(e1071)
  library(caret)
  library(randomForest)
  library(xgboost)
  
  # Load the dataset
  heart <- read.csv("C:\\Users\\ASUS\\OneDrive - Vishwakarma Institute of Technology\\DS\\Cp1\\heart.csv")
  
  # Normalize the predictors
  normalize <- function(x) {
    return((x - min(x)) / (max(x) - min(x)))
  }
  normalized_df <- as.data.frame(lapply(heart[, c(1:13)], normalize))
  
  # Combine the user inputs into a data frame
  user_data <- data.frame(age = age, sex = sex, cp = cp, trestbps = trestbps, chol = chol, fbs = fbs,
                          restecg = restecg, thalach = thalach, exang = exang, oldpeak = oldpeak,
                          slope = slope, ca = ca, thal = thal)
  
  # Train-test split
  set.seed(123)
  index <- createDataPartition(heart$target, p = 0.8, list = FALSE)
  train_data <- heart[index, ]
  test_data <- heart[-index, ]
  
  # Logistic Regression
  logistic_model <- glm(target ~ cp + thalach + slope + exang + oldpeak + thal + ca, 
                        data = train_data,
                        family = "binomial")
  lr_prediction <- ifelse(predict(logistic_model, newdata = user_data, type = "response") > 0.5, "yes", "no")
  
  # Random Forest
  rf_model <- randomForest(target ~ cp + thalach + slope + exang + oldpeak + thal + ca, 
                           data = train_data,
                           ntree = 500)
  rf_prediction <- ifelse(predict(rf_model, newdata = user_data, type = "response") > 0.5, "yes", "no")
  
  # Support Vector Machine (SVM)
  svm_model <- svm(target ~ cp + thalach + slope + exang + oldpeak + thal + ca,
                   data = train_data,
                   kernel = "linear")
  svm_prediction <- ifelse(predict(svm_model, newdata = user_data) > 0.5, "yes", "no")
  
  # XGBoost
  xgb_model <- xgboost(data = as.matrix(train_data[, c("cp", "thalach", "slope", "exang", "oldpeak", "thal", "ca")]), 
                       label = train_data$target,
                       objective = "binary:logistic",
                       nrounds = 10,
                       eta = 0.3,
                       max_depth = 6)
  xgb_prediction <- ifelse(predict(xgb_model, as.matrix(user_data[, c("cp", "thalach", "slope", "exang", "oldpeak", "thal", "ca")]), type = "response") > 0.5, "yes", "no")
  
  # Return the predicted classes from all models
  return(list(Logistic_Regression = lr_prediction,
              Random_Forest = rf_prediction,
              SVM = svm_prediction,
              XGBoost = xgb_prediction))
}

# Define the UI
ui <- fluidPage(
  tags$head(
    tags$style(HTML("
      body {
        background-image: url('https://storage.googleapis.com/kaggle-datasets-images/1582403/2603715/fc66626bcce9dec0f401f3f69c2ab2d1/dataset-cover.jpg?t=2021-09-10-18-13-42');
        background-size: cover;
        background-attachment: fixed;
      }
      .content-panel {
        background-color: rgba(255, 255, 255, 0.8);
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5);
      }
      .content-panel h3 {
        text-align: center;
      }
      .content-panel img {
        display: block;
        margin-left: auto;
        margin-right: auto;
      }
    "))
  ),
  titlePanel("Heart Disease Prediction"),
  sidebarLayout(
    sidebarPanel(
      class = "content-panel",
      tags$h3("Enter Patient Information"),
      numericInput("age", "Age:", value = NULL, min = 0),
      radioButtons("sex", "Sex:", choices = c("Female" = 0, "Male" = 1)),
      numericInput("cp", "Chest pain type (0-3):", value = NULL, min = 0, max = 3),
      numericInput("trestbps", "Resting blood pressure:", value = NULL, min = 0),
      numericInput("chol", "Serum cholesterol:", value = NULL, min = 0),
      radioButtons("fbs", "Fasting blood sugar > 120 mg/dl:", choices = c("False" = 0, "True" = 1)),
      numericInput("restecg", "Resting electrocardiographic results (0-2):", value = NULL, min = 0, max = 2),
      numericInput("thalach", "Maximum heart rate achieved:", value = NULL, min = 0),
      radioButtons("exang", "Exercise induced angina:", choices = c("No" = 0, "Yes" = 1)),
      numericInput("oldpeak", "ST depression induced by exercise relative to rest:", value = NULL),
      numericInput("slope", "Slope of the peak exercise ST segment (0-2):", value = NULL, min = 0, max = 2),
      numericInput("ca", "Number of major vessels colored by fluoroscopy (0-3):", value = NULL, min = 0, max = 3),
      numericInput("thal", "Thalassemia (0-3):", value = NULL, min = 0, max = 3),
      actionButton("predictBtn", "Predict", class = "btn-primary")
    ),
    mainPanel(
      class = "content-panel",
      tags$h3("Prediction Results"),
      textOutput("predictionOutput")
    )
  )
)

# Define the server logic
server <- function(input, output) {
  # When the predict button is clicked, perform prediction and display result
  observeEvent(input$predictBtn, {
    # Convert 'exang' to numeric
    exang_numeric <- as.numeric(input$exang)
    cat("Input Data:\n")
    print(c(input$age, input$sex, input$cp, input$trestbps, input$chol, input$fbs,
            input$restecg, input$thalach, exang_numeric, input$oldpeak, input$slope,
            input$ca, input$thal))
    
    # Call the predict_heart_disease function with user inputs
    predictions <- predict_heart_disease(
      input$age, input$sex, input$cp, input$trestbps, input$chol, input$fbs,
      input$restecg, input$thalach, exang_numeric, input$oldpeak, input$slope,
      input$ca, input$thal
    )
    cat("Predictions:\n")
    print(predictions)
    
    # Display predictions in the output area
    output$predictionOutput <- renderText({
      paste(
        "Logistic Regression predicted:", predictions$Logistic_Regression, "\n",
        "Random Forest predicted:", predictions$Random_Forest, "\n",
        "Support Vector Machine predicted:", predictions$SVM, "\n",
        "XGBoost predicted:", predictions$XGBoost
      )
    })
  })
}

# Run the application
shinyApp(ui = ui, server = server)
